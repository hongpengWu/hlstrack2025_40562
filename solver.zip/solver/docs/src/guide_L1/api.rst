..
   .. Copyright © 2021–2023 Advanced Micro Devices, Inc

`Terms and Conditions <https://www.amd.com/en/corporate/copyright>`_.
.. meta::
   :keywords: Matrix, Decomposition, Linear, Solver 
   :description: Vitis Solver library L1 application programming interface reference.
   :xlnxdocumentclass: Document
   :xlnxdocumenttype: Tutorials

APIs 
=====

.. include:: ../rst_L1/namespace_xf_solver.rst
   :start-after: FunctionSection
